package com.demosecuritymvc;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoSecurityMvcApplicationTests {

    @Test
    void contextLoads() {
    }

}
